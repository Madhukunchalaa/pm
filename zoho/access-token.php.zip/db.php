<?php
$host = "localhost";
$user = "jmsupruf_scaffolding";
$password = "Scaff@lding-";
$dbname = "jmsupruf_scaffolding";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>