<?php
include 'db.php';


session_start();

function loadaccesstoken($pdo){
$sql = "SELECT * FROM oauthtoken";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
$accesstokens=json_encode($result);
$rtoken=$result[0]['refresh_token'];
print_r($rtoken);
return $rtoken;
}

function getAccessToken($pdo){
    $rftoken=loadaccesstoken($pdo);
    
    $client_id = '1000.FKQ7FGPYER91U4IPC2GR879XYZGDIP';
$client_secret = '16250773fb680de492eff42d1e46220a9cd2c86384';
   

    $refresh_token = $rftoken;

$token_url = "https://accounts.zoho.com.au/oauth/v2/token";

$post_fields = http_build_query([
    'refresh_token' => $refresh_token,
    'client_id' => $client_id,
    'client_secret' => $client_secret,
    'grant_type' => 'refresh_token',
]);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);

$tokens = json_decode($response, true);
//print_r($tokens);
if (isset($tokens['access_token'])) {
    $newAccessToken = $tokens['access_token'];
    $_SESSION['access_token']=$tokens['access_token'];
    // Save the new access token securely
    echo "New Access Token: " . $newAccessToken;
} else {
    // Handle error
    echo "Error refreshing token: " . $response;


}
}
//getAccessToken($pdo);
// die;


?>
