<?php
include 'db.php';
session_start();
$client_id = '1000.FKQ7FGPYER91U4IPC2GR879XYZGDIP';
$client_secret = '16250773fb680de492eff42d1e46220a9cd2c86384';
$redirect_uri = 'https://scaffoldinginsurance.com.au/zoho/authcode.php';
$grant_token = '1000.9923be502a5af43efe56f4c2de0fa7fe.a847077737ab32a977fb472f7a72b465';

$token_url = "https://accounts.zoho.com.au/oauth/v2/token";

$post_fields = http_build_query([
    'grant_type' => 'authorization_code',
    'client_id' => $client_id,
    'client_secret' => $client_secret,
    'redirect_uri' => $redirect_uri,
    'code' => $grant_token,
]);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $token_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);
print_r($response);

$tokens = json_decode($response, true);
// var_dump($tokens);
if (isset($tokens['error'])=="invalid_code"){
    echo "invalid_code";
    die;
}
/**
 * 
 *  {
 * ["access_token"]=>"1000.d4dc04265aa3a844e80a01d724cfc83c.a1483bac7f34b392b08af6d056dc48bd" 
 * ["refresh_token"]=>"1000.fc6738c263c6fab8e1f1fe0978de817f.060e7c65104d78d20f6c7c7131bd6d4c"
 *  ["scope"]=>"ZohoCRM.modules.ALL"
 *  ["api_domain"]=> "https://www.zohoapis.in"
 *  ["token_type"]=> "Bearer" ["expires_in"]=> int(3600) }
 * 
 * 
 * 
 */


 if (isset($tokens['refresh_token']))
    $sql = "INSERT INTO oauthtoken (client_id, refresh_token,access_token,grant_token,expiry_time) VALUES 
    (:client_id, :refresh_token,:access_token,:grant_token,:expiry_time)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'client_id' =>$client_id,
         'refresh_token' =>$tokens['refresh_token'],
         'access_token' =>$tokens['access_token'],
         'grant_token' =>$grant_token,
         'expiry_time' =>$tokens["expires_in"]
        
        ]);
        if($stmt) {
            echo 'token Saved';
   
 }else{
    echo 'token  Not Saved';

 }
echo '------------------------------------------------------';
// var_dump($tokens['refresh_token']);
// $_SESSION['refresh_token']=$tokens['refresh_token'];
// $tokens['refresh_token']=
// $tokens['access_token'] and $tokens['refresh_token'] securely
?>
