<?php
include("db.php"); // Ensure correct path

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS homepage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    state VARCHAR(100) NOT NULL,
    zip VARCHAR(20) NOT NULL
)";
$conn->query($sql);

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($state) && !empty($zip)) {
        $sql = "INSERT INTO homepage (name, email, phone, state, zip) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("sssss", $name, $email, $phone, $state, $zip);
            if ($stmt->execute()) {
                echo "<h3 style='color: green;'>Data inserted successfully!</h3>";
            } else {
                echo "<h3 style='color: red;'>Error inserting data: " . $stmt->error . "</h3>";
            }
            $stmt->close();
        } else {
            echo "<h3 style='color: red;'>Error preparing statement: " . $conn->error . "</h3>";
        }
    } else {
        echo "<h3 style='color: red;'>All fields are required!</h3>";
    }
}

$conn->close();
?>
